namespace ET
{
    public class RobotManagerComponent: Entity, IAwake
    {
        
    }
}