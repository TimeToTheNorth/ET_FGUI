﻿namespace ET
{
    public class LocationProxyComponent: Entity, IAwake, IDestroy
    {
        public static LocationProxyComponent Instance;
    }
}