﻿namespace ET
{
    public enum MailboxType
    {
        MessageDispatcher,
        UnOrderMessageDispatcher,
        GateSession,
    }
}