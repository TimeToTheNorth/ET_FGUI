﻿namespace ET
{
	public class UnitComponent: Entity, IAwake, IDestroy
	{
	}
}