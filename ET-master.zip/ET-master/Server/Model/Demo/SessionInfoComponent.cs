﻿namespace ET
{
	public class SessionInfoComponent : Entity
	{
		public Session Session;
	}
}