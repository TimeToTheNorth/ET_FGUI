﻿namespace ET
{
    public class AOIManagerComponent: Entity, IAwake
    {
        public static int CellSize = 10 * 1000;
    }
}