﻿namespace ET
{
    public class GateMapComponent: Entity, IAwake
    {
        public Scene Scene;
    }
}