﻿namespace ET
{
    public static class AOISeeCheckHelper
    {
        public static bool IsCanSee(AOIEntity a, AOIEntity b)
        {
            return true;
        }
    }
}