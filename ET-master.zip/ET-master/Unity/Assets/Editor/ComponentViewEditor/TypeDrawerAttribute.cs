using System;

namespace ET
{
    public class TypeDrawerAttribute: Attribute
    {
    }
}