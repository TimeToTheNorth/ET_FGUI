using System;

namespace MongoDB.Bson.Serialization.Attributes
{
    public class BsonIgnoreAttribute: Attribute
    {
        
    }
}