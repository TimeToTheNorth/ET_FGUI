using System;

namespace MongoDB.Bson.Serialization.Attributes
{
    public class BsonDefaultValueAttribute: Attribute
    {
        public BsonDefaultValueAttribute(object o)
        {
        }
    }
}