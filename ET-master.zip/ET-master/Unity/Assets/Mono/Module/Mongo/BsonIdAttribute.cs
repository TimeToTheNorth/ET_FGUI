using System;

namespace MongoDB.Bson.Serialization.Attributes
{
    public class BsonIdAttribute: Attribute
    {
        
    }
}